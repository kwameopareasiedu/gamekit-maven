package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class FieldConfig extends dev.gamekit.ui.widgets.TextConfig implements Widget.Config {
	public java.awt.image.BufferedImage defaultBackground;
	public java.awt.image.BufferedImage focusBackground;
	public dev.gamekit.utils.Spacing edgeInsets;
	public dev.gamekit.utils.Spacing padding;
	public dev.gamekit.ui.events.FocusEvent.Handler focusListener;
	public dev.gamekit.ui.events.KeyCharEvent.Handler keyCharListener;
	public dev.gamekit.ui.events.ChangeEvent.Handler<java.lang.String> changeListener;
	public java.lang.String text;
	public java.awt.Font font;
	public java.lang.Integer fontSize;
	public java.lang.Double fontHeightRatio;
	public java.lang.Integer fontStyle;
	public java.awt.Color color;
	public java.awt.Color backgroundColor;
	public dev.gamekit.ui.enums.Alignment alignment;
	public java.lang.Boolean shadowEnabled;
	public java.lang.Integer shadowOffsetX;
	public java.lang.Integer shadowOffsetY;
	public java.awt.Color shadowColor;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof FieldConfig fieldConfig
			&& java.util.Objects.equals(defaultBackground, fieldConfig.defaultBackground)
			&& java.util.Objects.equals(focusBackground, fieldConfig.focusBackground)
			&& java.util.Objects.equals(edgeInsets, fieldConfig.edgeInsets)
			&& java.util.Objects.equals(padding, fieldConfig.padding)
			&& java.util.Objects.equals(text, fieldConfig.text)
			&& java.util.Objects.equals(font, fieldConfig.font)
			&& java.util.Objects.equals(fontSize, fieldConfig.fontSize)
			&& java.util.Objects.equals(fontHeightRatio, fieldConfig.fontHeightRatio)
			&& java.util.Objects.equals(fontStyle, fieldConfig.fontStyle)
			&& java.util.Objects.equals(color, fieldConfig.color)
			&& java.util.Objects.equals(backgroundColor, fieldConfig.backgroundColor)
			&& java.util.Objects.equals(alignment, fieldConfig.alignment)
			&& java.util.Objects.equals(shadowEnabled, fieldConfig.shadowEnabled)
			&& java.util.Objects.equals(shadowOffsetX, fieldConfig.shadowOffsetX)
			&& java.util.Objects.equals(shadowOffsetY, fieldConfig.shadowOffsetY)
			&& java.util.Objects.equals(shadowColor, fieldConfig.shadowColor);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Field fieldWidget = (dev.gamekit.ui.widgets.Field) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		fieldWidget.defaultBackground = coalesce(defaultBackground, nearestTheme.fieldDefaultBackground);
		fieldWidget.focusBackground = coalesce(focusBackground, nearestTheme.fieldFocusBackground);
		fieldWidget.edgeInsets = coalesce(edgeInsets, nearestTheme.fieldEdgeInsets);
		fieldWidget.padding = coalesce(padding, nearestTheme.fieldPadding);
		fieldWidget.focusListener = focusListener;
		fieldWidget.keyCharListener = keyCharListener;
		fieldWidget.changeListener = changeListener;
		fieldWidget.text = coalesce(text, nearestTheme.fieldText);
		fieldWidget.font = coalesce(font, nearestTheme.fieldFont);
		fieldWidget.fontSize = coalesce(fontSize, nearestTheme.fieldFontSize);
		fieldWidget.fontHeightRatio = coalesce(fontHeightRatio, nearestTheme.fieldFontHeightRatio);
		fieldWidget.fontStyle = coalesce(fontStyle, nearestTheme.fieldFontStyle);
		fieldWidget.color = coalesce(color, nearestTheme.fieldColor);
		fieldWidget.backgroundColor = coalesce(backgroundColor, nearestTheme.fieldBackgroundColor);
		fieldWidget.alignment = coalesce(alignment, nearestTheme.fieldAlignment);
		fieldWidget.shadowEnabled = coalesce(shadowEnabled, nearestTheme.fieldShadowEnabled);
		fieldWidget.shadowOffsetX = coalesce(shadowOffsetX, nearestTheme.fieldShadowOffsetX);
		fieldWidget.shadowOffsetY = coalesce(shadowOffsetY, nearestTheme.fieldShadowOffsetY);
		fieldWidget.shadowColor = coalesce(shadowColor, nearestTheme.fieldShadowColor);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<FieldConfig> { }
}