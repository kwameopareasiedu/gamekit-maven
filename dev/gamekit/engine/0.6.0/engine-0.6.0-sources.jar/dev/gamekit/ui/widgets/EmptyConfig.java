package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class EmptyConfig implements Widget.Config {
	@Override
	public boolean equals(Object obj) {
		return obj instanceof EmptyConfig emptyConfig;
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Empty emptyWidget = (dev.gamekit.ui.widgets.Empty) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<EmptyConfig> { }
}