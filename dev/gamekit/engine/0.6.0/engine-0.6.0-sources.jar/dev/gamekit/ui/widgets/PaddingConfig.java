package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class PaddingConfig implements Widget.Config {
	public dev.gamekit.utils.Spacing padding;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof PaddingConfig paddingConfig
			&& java.util.Objects.equals(padding, paddingConfig.padding);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Padding paddingWidget = (dev.gamekit.ui.widgets.Padding) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		paddingWidget.padding = coalesce(padding, nearestTheme.paddingPadding);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<PaddingConfig> { }
}