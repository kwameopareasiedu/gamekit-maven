package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class RowConfig extends dev.gamekit.ui.widgets.FlexConfig implements Widget.Config {
	public java.lang.Integer gapSize;
	public dev.gamekit.ui.enums.MainAxisAlignment mainAxisAlignment;
	public dev.gamekit.ui.enums.CrossAxisAlignment crossAxisAlignment;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof RowConfig rowConfig
			&& java.util.Objects.equals(gapSize, rowConfig.gapSize)
			&& java.util.Objects.equals(mainAxisAlignment, rowConfig.mainAxisAlignment)
			&& java.util.Objects.equals(crossAxisAlignment, rowConfig.crossAxisAlignment);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Row rowWidget = (dev.gamekit.ui.widgets.Row) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		rowWidget.gapSize = coalesce(gapSize, nearestTheme.rowGapSize);
		rowWidget.mainAxisAlignment = coalesce(mainAxisAlignment, nearestTheme.rowMainAxisAlignment);
		rowWidget.crossAxisAlignment = coalesce(crossAxisAlignment, nearestTheme.rowCrossAxisAlignment);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<RowConfig> { }
}