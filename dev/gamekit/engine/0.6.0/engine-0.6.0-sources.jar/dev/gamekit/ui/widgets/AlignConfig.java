package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class AlignConfig implements Widget.Config {
	public dev.gamekit.ui.enums.Alignment horizontalAlignment;
	public dev.gamekit.ui.enums.Alignment verticalAlignment;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof AlignConfig alignConfig
			&& java.util.Objects.equals(horizontalAlignment, alignConfig.horizontalAlignment)
			&& java.util.Objects.equals(verticalAlignment, alignConfig.verticalAlignment);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Align alignWidget = (dev.gamekit.ui.widgets.Align) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		alignWidget.horizontalAlignment = coalesce(horizontalAlignment, nearestTheme.alignHorizontalAlignment);
		alignWidget.verticalAlignment = coalesce(verticalAlignment, nearestTheme.alignVerticalAlignment);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<AlignConfig> { }
}