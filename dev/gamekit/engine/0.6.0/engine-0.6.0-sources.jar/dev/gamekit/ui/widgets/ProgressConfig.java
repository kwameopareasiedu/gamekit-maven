package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class ProgressConfig implements Widget.Config {
	public java.awt.image.BufferedImage trackBackground;
	public java.awt.image.BufferedImage fillBackground;
	public dev.gamekit.utils.Spacing trackEdgeInsets;
	public dev.gamekit.utils.Spacing fillEdgeInsets;
	public dev.gamekit.utils.Spacing fillMargin;
	public dev.gamekit.ui.widgets.Progress.FillMode fillMode;
	public java.lang.Double minValue;
	public java.lang.Double maxValue;
	public java.lang.Double value;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof ProgressConfig progressConfig
			&& java.util.Objects.equals(trackBackground, progressConfig.trackBackground)
			&& java.util.Objects.equals(fillBackground, progressConfig.fillBackground)
			&& java.util.Objects.equals(trackEdgeInsets, progressConfig.trackEdgeInsets)
			&& java.util.Objects.equals(fillEdgeInsets, progressConfig.fillEdgeInsets)
			&& java.util.Objects.equals(fillMargin, progressConfig.fillMargin)
			&& java.util.Objects.equals(fillMode, progressConfig.fillMode)
			&& java.util.Objects.equals(minValue, progressConfig.minValue)
			&& java.util.Objects.equals(maxValue, progressConfig.maxValue)
			&& java.util.Objects.equals(value, progressConfig.value);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Progress progressWidget = (dev.gamekit.ui.widgets.Progress) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		progressWidget.trackBackground = coalesce(trackBackground, nearestTheme.progressTrackBackground);
		progressWidget.fillBackground = coalesce(fillBackground, nearestTheme.progressFillBackground);
		progressWidget.trackEdgeInsets = coalesce(trackEdgeInsets, nearestTheme.progressTrackEdgeInsets);
		progressWidget.fillEdgeInsets = coalesce(fillEdgeInsets, nearestTheme.progressFillEdgeInsets);
		progressWidget.fillMargin = coalesce(fillMargin, nearestTheme.progressFillMargin);
		progressWidget.fillMode = coalesce(fillMode, nearestTheme.progressFillMode);
		progressWidget.minValue = coalesce(minValue, nearestTheme.progressMinValue);
		progressWidget.maxValue = coalesce(maxValue, nearestTheme.progressMaxValue);
		progressWidget.value = coalesce(value, nearestTheme.progressValue);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<ProgressConfig> { }
}