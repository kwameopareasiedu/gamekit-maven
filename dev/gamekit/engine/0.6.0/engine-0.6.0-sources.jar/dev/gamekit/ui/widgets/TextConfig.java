package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class TextConfig implements Widget.Config {
	public java.lang.String text;
	public java.awt.Font font;
	public java.lang.Integer fontSize;
	public java.lang.Double fontHeightRatio;
	public java.lang.Integer fontStyle;
	public java.awt.Color color;
	public java.awt.Color backgroundColor;
	public dev.gamekit.ui.enums.Alignment alignment;
	public java.lang.Boolean shadowEnabled;
	public java.lang.Integer shadowOffsetX;
	public java.lang.Integer shadowOffsetY;
	public java.awt.Color shadowColor;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof TextConfig textConfig
			&& java.util.Objects.equals(text, textConfig.text)
			&& java.util.Objects.equals(font, textConfig.font)
			&& java.util.Objects.equals(fontSize, textConfig.fontSize)
			&& java.util.Objects.equals(fontHeightRatio, textConfig.fontHeightRatio)
			&& java.util.Objects.equals(fontStyle, textConfig.fontStyle)
			&& java.util.Objects.equals(color, textConfig.color)
			&& java.util.Objects.equals(backgroundColor, textConfig.backgroundColor)
			&& java.util.Objects.equals(alignment, textConfig.alignment)
			&& java.util.Objects.equals(shadowEnabled, textConfig.shadowEnabled)
			&& java.util.Objects.equals(shadowOffsetX, textConfig.shadowOffsetX)
			&& java.util.Objects.equals(shadowOffsetY, textConfig.shadowOffsetY)
			&& java.util.Objects.equals(shadowColor, textConfig.shadowColor);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Text textWidget = (dev.gamekit.ui.widgets.Text) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		textWidget.text = coalesce(text, nearestTheme.textText);
		textWidget.font = coalesce(font, nearestTheme.textFont);
		textWidget.fontSize = coalesce(fontSize, nearestTheme.textFontSize);
		textWidget.fontHeightRatio = coalesce(fontHeightRatio, nearestTheme.textFontHeightRatio);
		textWidget.fontStyle = coalesce(fontStyle, nearestTheme.textFontStyle);
		textWidget.color = coalesce(color, nearestTheme.textColor);
		textWidget.backgroundColor = coalesce(backgroundColor, nearestTheme.textBackgroundColor);
		textWidget.alignment = coalesce(alignment, nearestTheme.textAlignment);
		textWidget.shadowEnabled = coalesce(shadowEnabled, nearestTheme.textShadowEnabled);
		textWidget.shadowOffsetX = coalesce(shadowOffsetX, nearestTheme.textShadowOffsetX);
		textWidget.shadowOffsetY = coalesce(shadowOffsetY, nearestTheme.textShadowOffsetY);
		textWidget.shadowColor = coalesce(shadowColor, nearestTheme.textShadowColor);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<TextConfig> { }
}