package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class ScaledConfig implements Widget.Config {
	public java.lang.Double scale;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof ScaledConfig scaledConfig
			&& java.util.Objects.equals(scale, scaledConfig.scale);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Scaled scaledWidget = (dev.gamekit.ui.widgets.Scaled) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		scaledWidget.scale = coalesce(scale, nearestTheme.scaledScale);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<ScaledConfig> { }
}