package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class ImageConfig implements Widget.Config {
	public java.awt.image.BufferedImage image;
	public dev.gamekit.ui.enums.ImageFit fit;
	public dev.gamekit.settings.ImageInterpolation interpolation;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof ImageConfig imageConfig
			&& java.util.Objects.equals(image, imageConfig.image)
			&& java.util.Objects.equals(fit, imageConfig.fit)
			&& java.util.Objects.equals(interpolation, imageConfig.interpolation);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Image imageWidget = (dev.gamekit.ui.widgets.Image) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		imageWidget.image = image;
		imageWidget.fit = coalesce(fit, nearestTheme.imageFit);
		imageWidget.interpolation = coalesce(interpolation, nearestTheme.imageInterpolation);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<ImageConfig> { }
}