package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class CheckboxConfig implements Widget.Config {
	public java.awt.image.BufferedImage defaultIcon;
	public java.awt.image.BufferedImage toggledIcon;
	public dev.gamekit.utils.Spacing iconPadding;
	public java.lang.Integer iconWidth;
	public java.lang.Integer iconHeight;
	public java.lang.Integer gapSize;
	public java.lang.Boolean toggled;
	public dev.gamekit.ui.events.ChangeEvent.Handler<java.lang.Boolean> changeListener;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof CheckboxConfig checkboxConfig
			&& java.util.Objects.equals(defaultIcon, checkboxConfig.defaultIcon)
			&& java.util.Objects.equals(toggledIcon, checkboxConfig.toggledIcon)
			&& java.util.Objects.equals(iconPadding, checkboxConfig.iconPadding)
			&& java.util.Objects.equals(iconWidth, checkboxConfig.iconWidth)
			&& java.util.Objects.equals(iconHeight, checkboxConfig.iconHeight)
			&& java.util.Objects.equals(gapSize, checkboxConfig.gapSize)
			&& java.util.Objects.equals(toggled, checkboxConfig.toggled);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Checkbox checkboxWidget = (dev.gamekit.ui.widgets.Checkbox) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		checkboxWidget.defaultIcon = coalesce(defaultIcon, nearestTheme.checkboxDefaultIcon);
		checkboxWidget.toggledIcon = coalesce(toggledIcon, nearestTheme.checkboxToggledIcon);
		checkboxWidget.iconPadding = coalesce(iconPadding, nearestTheme.checkboxIconPadding);
		checkboxWidget.iconWidth = coalesce(iconWidth, nearestTheme.checkboxIconWidth);
		checkboxWidget.iconHeight = coalesce(iconHeight, nearestTheme.checkboxIconHeight);
		checkboxWidget.gapSize = coalesce(gapSize, nearestTheme.checkboxGapSize);
		checkboxWidget.toggled = coalesce(toggled, nearestTheme.checkboxToggled);
		checkboxWidget.changeListener = changeListener;
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<CheckboxConfig> { }
}