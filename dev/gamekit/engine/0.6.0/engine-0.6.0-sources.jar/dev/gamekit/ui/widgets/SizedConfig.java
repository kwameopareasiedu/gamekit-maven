package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class SizedConfig implements Widget.Config {
	public java.lang.Boolean useIntrinsicWidth;
	public java.lang.Boolean useIntrinsicHeight;
	public java.lang.Double fractionalWidth;
	public java.lang.Double fractionalHeight;
	public java.lang.Double fixedWidth;
	public java.lang.Double fixedHeight;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof SizedConfig sizedConfig
			&& java.util.Objects.equals(useIntrinsicWidth, sizedConfig.useIntrinsicWidth)
			&& java.util.Objects.equals(useIntrinsicHeight, sizedConfig.useIntrinsicHeight)
			&& java.util.Objects.equals(fractionalWidth, sizedConfig.fractionalWidth)
			&& java.util.Objects.equals(fractionalHeight, sizedConfig.fractionalHeight)
			&& java.util.Objects.equals(fixedWidth, sizedConfig.fixedWidth)
			&& java.util.Objects.equals(fixedHeight, sizedConfig.fixedHeight);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Sized sizedWidget = (dev.gamekit.ui.widgets.Sized) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		sizedWidget.useIntrinsicWidth = coalesce(useIntrinsicWidth, nearestTheme.sizedUseIntrinsicWidth);
		sizedWidget.useIntrinsicHeight = coalesce(useIntrinsicHeight, nearestTheme.sizedUseIntrinsicHeight);
		sizedWidget.fractionalWidth = coalesce(fractionalWidth, nearestTheme.sizedFractionalWidth);
		sizedWidget.fractionalHeight = coalesce(fractionalHeight, nearestTheme.sizedFractionalHeight);
		sizedWidget.fixedWidth = coalesce(fixedWidth, nearestTheme.sizedFixedWidth);
		sizedWidget.fixedHeight = coalesce(fixedHeight, nearestTheme.sizedFixedHeight);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<SizedConfig> { }
}