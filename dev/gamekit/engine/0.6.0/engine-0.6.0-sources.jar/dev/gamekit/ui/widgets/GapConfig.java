package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class GapConfig implements Widget.Config {
	public java.lang.Integer width;
	public java.lang.Integer height;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof GapConfig gapConfig
			&& java.util.Objects.equals(width, gapConfig.width)
			&& java.util.Objects.equals(height, gapConfig.height);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Gap gapWidget = (dev.gamekit.ui.widgets.Gap) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		gapWidget.width = coalesce(width, nearestTheme.gapWidth);
		gapWidget.height = coalesce(height, nearestTheme.gapHeight);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<GapConfig> { }
}