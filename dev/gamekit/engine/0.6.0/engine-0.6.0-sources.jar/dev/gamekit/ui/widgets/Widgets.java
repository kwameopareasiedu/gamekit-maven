package dev.gamekit.ui.widgets;

class Widgets {
  private Widgets() { }

	static dev.gamekit.ui.widgets.AlignConfig configureAlign(dev.gamekit.ui.widgets.AlignConfig.Updater updater) {
		dev.gamekit.ui.widgets.AlignConfig config = new dev.gamekit.ui.widgets.AlignConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.ButtonConfig configureButton(dev.gamekit.ui.widgets.ButtonConfig.Updater updater) {
		dev.gamekit.ui.widgets.ButtonConfig config = new dev.gamekit.ui.widgets.ButtonConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.CheckboxConfig configureCheckbox(dev.gamekit.ui.widgets.CheckboxConfig.Updater updater) {
		dev.gamekit.ui.widgets.CheckboxConfig config = new dev.gamekit.ui.widgets.CheckboxConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.ColoredConfig configureColored(dev.gamekit.ui.widgets.ColoredConfig.Updater updater) {
		dev.gamekit.ui.widgets.ColoredConfig config = new dev.gamekit.ui.widgets.ColoredConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.ColumnConfig configureColumn(dev.gamekit.ui.widgets.ColumnConfig.Updater updater) {
		dev.gamekit.ui.widgets.ColumnConfig config = new dev.gamekit.ui.widgets.ColumnConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.ComposeConfig configureCompose(dev.gamekit.ui.widgets.ComposeConfig.Updater updater) {
		dev.gamekit.ui.widgets.ComposeConfig config = new dev.gamekit.ui.widgets.ComposeConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.EmptyConfig configureEmpty(dev.gamekit.ui.widgets.EmptyConfig.Updater updater) {
		dev.gamekit.ui.widgets.EmptyConfig config = new dev.gamekit.ui.widgets.EmptyConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.FieldConfig configureField(dev.gamekit.ui.widgets.FieldConfig.Updater updater) {
		dev.gamekit.ui.widgets.FieldConfig config = new dev.gamekit.ui.widgets.FieldConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.FlexConfig configureFlex(dev.gamekit.ui.widgets.FlexConfig.Updater updater) {
		dev.gamekit.ui.widgets.FlexConfig config = new dev.gamekit.ui.widgets.FlexConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.GapConfig configureGap(dev.gamekit.ui.widgets.GapConfig.Updater updater) {
		dev.gamekit.ui.widgets.GapConfig config = new dev.gamekit.ui.widgets.GapConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.ImageConfig configureImage(dev.gamekit.ui.widgets.ImageConfig.Updater updater) {
		dev.gamekit.ui.widgets.ImageConfig config = new dev.gamekit.ui.widgets.ImageConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.OpacityConfig configureOpacity(dev.gamekit.ui.widgets.OpacityConfig.Updater updater) {
		dev.gamekit.ui.widgets.OpacityConfig config = new dev.gamekit.ui.widgets.OpacityConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.PaddingConfig configurePadding(dev.gamekit.ui.widgets.PaddingConfig.Updater updater) {
		dev.gamekit.ui.widgets.PaddingConfig config = new dev.gamekit.ui.widgets.PaddingConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.PanelConfig configurePanel(dev.gamekit.ui.widgets.PanelConfig.Updater updater) {
		dev.gamekit.ui.widgets.PanelConfig config = new dev.gamekit.ui.widgets.PanelConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.ProgressConfig configureProgress(dev.gamekit.ui.widgets.ProgressConfig.Updater updater) {
		dev.gamekit.ui.widgets.ProgressConfig config = new dev.gamekit.ui.widgets.ProgressConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.RotatedConfig configureRotated(dev.gamekit.ui.widgets.RotatedConfig.Updater updater) {
		dev.gamekit.ui.widgets.RotatedConfig config = new dev.gamekit.ui.widgets.RotatedConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.RowConfig configureRow(dev.gamekit.ui.widgets.RowConfig.Updater updater) {
		dev.gamekit.ui.widgets.RowConfig config = new dev.gamekit.ui.widgets.RowConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.ScaledConfig configureScaled(dev.gamekit.ui.widgets.ScaledConfig.Updater updater) {
		dev.gamekit.ui.widgets.ScaledConfig config = new dev.gamekit.ui.widgets.ScaledConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.SizedConfig configureSized(dev.gamekit.ui.widgets.SizedConfig.Updater updater) {
		dev.gamekit.ui.widgets.SizedConfig config = new dev.gamekit.ui.widgets.SizedConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.SliderConfig configureSlider(dev.gamekit.ui.widgets.SliderConfig.Updater updater) {
		dev.gamekit.ui.widgets.SliderConfig config = new dev.gamekit.ui.widgets.SliderConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.StackConfig configureStack(dev.gamekit.ui.widgets.StackConfig.Updater updater) {
		dev.gamekit.ui.widgets.StackConfig config = new dev.gamekit.ui.widgets.StackConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.TextConfig configureText(dev.gamekit.ui.widgets.TextConfig.Updater updater) {
		dev.gamekit.ui.widgets.TextConfig config = new dev.gamekit.ui.widgets.TextConfig();
		updater.update(config);
		return config;
	}

	static dev.gamekit.ui.widgets.ThemeConfig configureTheme(dev.gamekit.ui.widgets.ThemeConfig.Updater updater) {
		dev.gamekit.ui.widgets.ThemeConfig config = new dev.gamekit.ui.widgets.ThemeConfig();
		updater.update(config);
		return config;
	}

}