package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class ComposeConfig implements Widget.Config {
	@Override
	public boolean equals(Object obj) {
		return obj instanceof ComposeConfig composeConfig;
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Compose composeWidget = (dev.gamekit.ui.widgets.Compose) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<ComposeConfig> { }
}