package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class SliderConfig extends dev.gamekit.ui.widgets.ProgressConfig implements Widget.Config {
	public java.awt.image.BufferedImage thumbBackground;
	public dev.gamekit.utils.Spacing thumbEdgeInsets;
	public java.lang.Integer thumbWidth;
	public java.lang.Integer thumbHeight;
	public dev.gamekit.ui.events.ChangeEvent.Handler<java.lang.Double> changeListener;
	public java.awt.image.BufferedImage trackBackground;
	public java.awt.image.BufferedImage fillBackground;
	public dev.gamekit.utils.Spacing trackEdgeInsets;
	public dev.gamekit.utils.Spacing fillEdgeInsets;
	public dev.gamekit.utils.Spacing fillMargin;
	public dev.gamekit.ui.widgets.Progress.FillMode fillMode;
	public java.lang.Double minValue;
	public java.lang.Double maxValue;
	public java.lang.Double value;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof SliderConfig sliderConfig
			&& java.util.Objects.equals(thumbBackground, sliderConfig.thumbBackground)
			&& java.util.Objects.equals(thumbEdgeInsets, sliderConfig.thumbEdgeInsets)
			&& java.util.Objects.equals(thumbWidth, sliderConfig.thumbWidth)
			&& java.util.Objects.equals(thumbHeight, sliderConfig.thumbHeight)
			&& java.util.Objects.equals(trackBackground, sliderConfig.trackBackground)
			&& java.util.Objects.equals(fillBackground, sliderConfig.fillBackground)
			&& java.util.Objects.equals(trackEdgeInsets, sliderConfig.trackEdgeInsets)
			&& java.util.Objects.equals(fillEdgeInsets, sliderConfig.fillEdgeInsets)
			&& java.util.Objects.equals(fillMargin, sliderConfig.fillMargin)
			&& java.util.Objects.equals(fillMode, sliderConfig.fillMode)
			&& java.util.Objects.equals(minValue, sliderConfig.minValue)
			&& java.util.Objects.equals(maxValue, sliderConfig.maxValue)
			&& java.util.Objects.equals(value, sliderConfig.value);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Slider sliderWidget = (dev.gamekit.ui.widgets.Slider) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		sliderWidget.thumbBackground = coalesce(thumbBackground, nearestTheme.sliderThumbBackground);
		sliderWidget.thumbEdgeInsets = coalesce(thumbEdgeInsets, nearestTheme.sliderThumbEdgeInsets);
		sliderWidget.thumbWidth = coalesce(thumbWidth, nearestTheme.sliderThumbWidth);
		sliderWidget.thumbHeight = coalesce(thumbHeight, nearestTheme.sliderThumbHeight);
		sliderWidget.changeListener = changeListener;
		sliderWidget.trackBackground = coalesce(trackBackground, nearestTheme.sliderTrackBackground);
		sliderWidget.fillBackground = coalesce(fillBackground, nearestTheme.sliderFillBackground);
		sliderWidget.trackEdgeInsets = coalesce(trackEdgeInsets, nearestTheme.sliderTrackEdgeInsets);
		sliderWidget.fillEdgeInsets = coalesce(fillEdgeInsets, nearestTheme.sliderFillEdgeInsets);
		sliderWidget.fillMargin = coalesce(fillMargin, nearestTheme.sliderFillMargin);
		sliderWidget.fillMode = coalesce(fillMode, nearestTheme.sliderFillMode);
		sliderWidget.minValue = coalesce(minValue, nearestTheme.sliderMinValue);
		sliderWidget.maxValue = coalesce(maxValue, nearestTheme.sliderMaxValue);
		sliderWidget.value = coalesce(value, nearestTheme.sliderValue);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<SliderConfig> { }
}