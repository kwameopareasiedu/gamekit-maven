package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class OpacityConfig implements Widget.Config {
	public java.lang.Double opacity;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof OpacityConfig opacityConfig
			&& java.util.Objects.equals(opacity, opacityConfig.opacity);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Opacity opacityWidget = (dev.gamekit.ui.widgets.Opacity) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		opacityWidget.opacity = coalesce(opacity, nearestTheme.opacityOpacity);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<OpacityConfig> { }
}