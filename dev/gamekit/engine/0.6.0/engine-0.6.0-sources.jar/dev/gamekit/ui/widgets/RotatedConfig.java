package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class RotatedConfig implements Widget.Config {
	public java.lang.Double rotation;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof RotatedConfig rotatedConfig
			&& java.util.Objects.equals(rotation, rotatedConfig.rotation);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Rotated rotatedWidget = (dev.gamekit.ui.widgets.Rotated) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		rotatedWidget.rotation = rotation;
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<RotatedConfig> { }
}