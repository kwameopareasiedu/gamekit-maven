package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class ButtonConfig implements Widget.Config {
	public java.awt.image.BufferedImage defaultBackground;
	public java.awt.image.BufferedImage hoverBackground;
	public java.awt.image.BufferedImage pressedBackground;
	public dev.gamekit.utils.Spacing padding;
	public dev.gamekit.ui.events.MouseEvent.Handler mouseListener;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof ButtonConfig buttonConfig
			&& java.util.Objects.equals(defaultBackground, buttonConfig.defaultBackground)
			&& java.util.Objects.equals(hoverBackground, buttonConfig.hoverBackground)
			&& java.util.Objects.equals(pressedBackground, buttonConfig.pressedBackground)
			&& java.util.Objects.equals(padding, buttonConfig.padding);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Button buttonWidget = (dev.gamekit.ui.widgets.Button) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		buttonWidget.defaultBackground = coalesce(defaultBackground, nearestTheme.buttonDefaultBackground);
		buttonWidget.hoverBackground = coalesce(hoverBackground, nearestTheme.buttonHoverBackground);
		buttonWidget.pressedBackground = coalesce(pressedBackground, nearestTheme.buttonPressedBackground);
		buttonWidget.padding = coalesce(padding, nearestTheme.buttonPadding);
		buttonWidget.mouseListener = mouseListener;
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<ButtonConfig> { }
}