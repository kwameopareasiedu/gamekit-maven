package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class StackConfig implements Widget.Config {
	@Override
	public boolean equals(Object obj) {
		return obj instanceof StackConfig stackConfig;
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Stack stackWidget = (dev.gamekit.ui.widgets.Stack) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<StackConfig> { }
}