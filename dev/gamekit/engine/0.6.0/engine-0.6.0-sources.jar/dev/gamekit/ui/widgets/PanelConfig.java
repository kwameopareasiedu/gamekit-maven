package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class PanelConfig implements Widget.Config {
	public java.awt.image.BufferedImage background;
	public dev.gamekit.utils.Spacing padding;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof PanelConfig panelConfig
			&& java.util.Objects.equals(background, panelConfig.background)
			&& java.util.Objects.equals(padding, panelConfig.padding);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Panel panelWidget = (dev.gamekit.ui.widgets.Panel) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		panelWidget.background = coalesce(background, nearestTheme.panelBackground);
		panelWidget.padding = coalesce(padding, nearestTheme.panelPadding);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<PanelConfig> { }
}