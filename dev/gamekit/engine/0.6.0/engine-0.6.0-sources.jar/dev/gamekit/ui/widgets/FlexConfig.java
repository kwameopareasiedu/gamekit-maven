package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class FlexConfig implements Widget.Config {
	public java.lang.Integer gapSize;
	public dev.gamekit.ui.enums.MainAxisAlignment mainAxisAlignment;
	public dev.gamekit.ui.enums.CrossAxisAlignment crossAxisAlignment;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof FlexConfig flexConfig
			&& java.util.Objects.equals(gapSize, flexConfig.gapSize)
			&& java.util.Objects.equals(mainAxisAlignment, flexConfig.mainAxisAlignment)
			&& java.util.Objects.equals(crossAxisAlignment, flexConfig.crossAxisAlignment);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Flex flexWidget = (dev.gamekit.ui.widgets.Flex) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		flexWidget.gapSize = coalesce(gapSize, nearestTheme.flexGapSize);
		flexWidget.mainAxisAlignment = coalesce(mainAxisAlignment, nearestTheme.flexMainAxisAlignment);
		flexWidget.crossAxisAlignment = coalesce(crossAxisAlignment, nearestTheme.flexCrossAxisAlignment);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<FlexConfig> { }
}