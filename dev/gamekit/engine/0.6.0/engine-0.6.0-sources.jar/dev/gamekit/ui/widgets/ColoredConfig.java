package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class ColoredConfig implements Widget.Config {
	public java.awt.Color color;
	public java.lang.Integer borderRadius;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof ColoredConfig coloredConfig
			&& java.util.Objects.equals(color, coloredConfig.color)
			&& java.util.Objects.equals(borderRadius, coloredConfig.borderRadius);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Colored coloredWidget = (dev.gamekit.ui.widgets.Colored) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		coloredWidget.color = coalesce(color, nearestTheme.coloredColor);
		coloredWidget.borderRadius = coalesce(borderRadius, nearestTheme.coloredBorderRadius);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<ColoredConfig> { }
}