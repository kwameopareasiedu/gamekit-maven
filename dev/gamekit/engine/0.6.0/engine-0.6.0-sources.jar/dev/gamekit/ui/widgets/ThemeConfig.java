package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class ThemeConfig implements Widget.Config {
	public dev.gamekit.ui.enums.Alignment alignHorizontalAlignment;
	public dev.gamekit.ui.enums.Alignment alignVerticalAlignment;
	public java.awt.image.BufferedImage buttonDefaultBackground;
	public java.awt.image.BufferedImage buttonHoverBackground;
	public java.awt.image.BufferedImage buttonPressedBackground;
	public dev.gamekit.utils.Spacing buttonPadding;
	public java.awt.image.BufferedImage checkboxDefaultIcon;
	public java.awt.image.BufferedImage checkboxToggledIcon;
	public dev.gamekit.utils.Spacing checkboxIconPadding;
	public java.lang.Integer checkboxIconWidth;
	public java.lang.Integer checkboxIconHeight;
	public java.lang.Integer checkboxGapSize;
	public java.lang.Boolean checkboxToggled;
	public java.awt.Color coloredColor;
	public java.lang.Integer coloredBorderRadius;
	public java.lang.Integer columnGapSize;
	public dev.gamekit.ui.enums.MainAxisAlignment columnMainAxisAlignment;
	public dev.gamekit.ui.enums.CrossAxisAlignment columnCrossAxisAlignment;
	public java.awt.image.BufferedImage fieldDefaultBackground;
	public java.awt.image.BufferedImage fieldFocusBackground;
	public dev.gamekit.utils.Spacing fieldEdgeInsets;
	public dev.gamekit.utils.Spacing fieldPadding;
	public java.lang.String fieldText;
	public java.awt.Font fieldFont;
	public java.lang.Integer fieldFontSize;
	public java.lang.Double fieldFontHeightRatio;
	public java.lang.Integer fieldFontStyle;
	public java.awt.Color fieldColor;
	public java.awt.Color fieldBackgroundColor;
	public dev.gamekit.ui.enums.Alignment fieldAlignment;
	public java.lang.Boolean fieldShadowEnabled;
	public java.lang.Integer fieldShadowOffsetX;
	public java.lang.Integer fieldShadowOffsetY;
	public java.awt.Color fieldShadowColor;
	public java.lang.Integer flexGapSize;
	public dev.gamekit.ui.enums.MainAxisAlignment flexMainAxisAlignment;
	public dev.gamekit.ui.enums.CrossAxisAlignment flexCrossAxisAlignment;
	public java.lang.Integer gapWidth;
	public java.lang.Integer gapHeight;
	public dev.gamekit.ui.enums.ImageFit imageFit;
	public dev.gamekit.settings.ImageInterpolation imageInterpolation;
	public java.lang.Double opacityOpacity;
	public dev.gamekit.utils.Spacing paddingPadding;
	public java.awt.image.BufferedImage panelBackground;
	public dev.gamekit.utils.Spacing panelPadding;
	public java.awt.image.BufferedImage progressTrackBackground;
	public java.awt.image.BufferedImage progressFillBackground;
	public dev.gamekit.utils.Spacing progressTrackEdgeInsets;
	public dev.gamekit.utils.Spacing progressFillEdgeInsets;
	public dev.gamekit.utils.Spacing progressFillMargin;
	public dev.gamekit.ui.widgets.Progress.FillMode progressFillMode;
	public java.lang.Double progressMinValue;
	public java.lang.Double progressMaxValue;
	public java.lang.Double progressValue;
	public java.lang.Integer rowGapSize;
	public dev.gamekit.ui.enums.MainAxisAlignment rowMainAxisAlignment;
	public dev.gamekit.ui.enums.CrossAxisAlignment rowCrossAxisAlignment;
	public java.lang.Double scaledScale;
	public java.lang.Boolean sizedUseIntrinsicWidth;
	public java.lang.Boolean sizedUseIntrinsicHeight;
	public java.lang.Double sizedFractionalWidth;
	public java.lang.Double sizedFractionalHeight;
	public java.lang.Double sizedFixedWidth;
	public java.lang.Double sizedFixedHeight;
	public java.awt.image.BufferedImage sliderThumbBackground;
	public dev.gamekit.utils.Spacing sliderThumbEdgeInsets;
	public java.lang.Integer sliderThumbWidth;
	public java.lang.Integer sliderThumbHeight;
	public java.awt.image.BufferedImage sliderTrackBackground;
	public java.awt.image.BufferedImage sliderFillBackground;
	public dev.gamekit.utils.Spacing sliderTrackEdgeInsets;
	public dev.gamekit.utils.Spacing sliderFillEdgeInsets;
	public dev.gamekit.utils.Spacing sliderFillMargin;
	public dev.gamekit.ui.widgets.Progress.FillMode sliderFillMode;
	public java.lang.Double sliderMinValue;
	public java.lang.Double sliderMaxValue;
	public java.lang.Double sliderValue;
	public java.lang.String textText;
	public java.awt.Font textFont;
	public java.lang.Integer textFontSize;
	public java.lang.Double textFontHeightRatio;
	public java.lang.Integer textFontStyle;
	public java.awt.Color textColor;
	public java.awt.Color textBackgroundColor;
	public dev.gamekit.ui.enums.Alignment textAlignment;
	public java.lang.Boolean textShadowEnabled;
	public java.lang.Integer textShadowOffsetX;
	public java.lang.Integer textShadowOffsetY;
	public java.awt.Color textShadowColor;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof ThemeConfig themeConfig
			&& java.util.Objects.equals(alignHorizontalAlignment, themeConfig.alignHorizontalAlignment)
			&& java.util.Objects.equals(alignVerticalAlignment, themeConfig.alignVerticalAlignment)
			&& java.util.Objects.equals(buttonDefaultBackground, themeConfig.buttonDefaultBackground)
			&& java.util.Objects.equals(buttonHoverBackground, themeConfig.buttonHoverBackground)
			&& java.util.Objects.equals(buttonPressedBackground, themeConfig.buttonPressedBackground)
			&& java.util.Objects.equals(buttonPadding, themeConfig.buttonPadding)
			&& java.util.Objects.equals(checkboxDefaultIcon, themeConfig.checkboxDefaultIcon)
			&& java.util.Objects.equals(checkboxToggledIcon, themeConfig.checkboxToggledIcon)
			&& java.util.Objects.equals(checkboxIconPadding, themeConfig.checkboxIconPadding)
			&& java.util.Objects.equals(checkboxIconWidth, themeConfig.checkboxIconWidth)
			&& java.util.Objects.equals(checkboxIconHeight, themeConfig.checkboxIconHeight)
			&& java.util.Objects.equals(checkboxGapSize, themeConfig.checkboxGapSize)
			&& java.util.Objects.equals(checkboxToggled, themeConfig.checkboxToggled)
			&& java.util.Objects.equals(coloredColor, themeConfig.coloredColor)
			&& java.util.Objects.equals(coloredBorderRadius, themeConfig.coloredBorderRadius)
			&& java.util.Objects.equals(columnGapSize, themeConfig.columnGapSize)
			&& java.util.Objects.equals(columnMainAxisAlignment, themeConfig.columnMainAxisAlignment)
			&& java.util.Objects.equals(columnCrossAxisAlignment, themeConfig.columnCrossAxisAlignment)
			&& java.util.Objects.equals(fieldDefaultBackground, themeConfig.fieldDefaultBackground)
			&& java.util.Objects.equals(fieldFocusBackground, themeConfig.fieldFocusBackground)
			&& java.util.Objects.equals(fieldEdgeInsets, themeConfig.fieldEdgeInsets)
			&& java.util.Objects.equals(fieldPadding, themeConfig.fieldPadding)
			&& java.util.Objects.equals(fieldText, themeConfig.fieldText)
			&& java.util.Objects.equals(fieldFont, themeConfig.fieldFont)
			&& java.util.Objects.equals(fieldFontSize, themeConfig.fieldFontSize)
			&& java.util.Objects.equals(fieldFontHeightRatio, themeConfig.fieldFontHeightRatio)
			&& java.util.Objects.equals(fieldFontStyle, themeConfig.fieldFontStyle)
			&& java.util.Objects.equals(fieldColor, themeConfig.fieldColor)
			&& java.util.Objects.equals(fieldBackgroundColor, themeConfig.fieldBackgroundColor)
			&& java.util.Objects.equals(fieldAlignment, themeConfig.fieldAlignment)
			&& java.util.Objects.equals(fieldShadowEnabled, themeConfig.fieldShadowEnabled)
			&& java.util.Objects.equals(fieldShadowOffsetX, themeConfig.fieldShadowOffsetX)
			&& java.util.Objects.equals(fieldShadowOffsetY, themeConfig.fieldShadowOffsetY)
			&& java.util.Objects.equals(fieldShadowColor, themeConfig.fieldShadowColor)
			&& java.util.Objects.equals(flexGapSize, themeConfig.flexGapSize)
			&& java.util.Objects.equals(flexMainAxisAlignment, themeConfig.flexMainAxisAlignment)
			&& java.util.Objects.equals(flexCrossAxisAlignment, themeConfig.flexCrossAxisAlignment)
			&& java.util.Objects.equals(gapWidth, themeConfig.gapWidth)
			&& java.util.Objects.equals(gapHeight, themeConfig.gapHeight)
			&& java.util.Objects.equals(imageFit, themeConfig.imageFit)
			&& java.util.Objects.equals(imageInterpolation, themeConfig.imageInterpolation)
			&& java.util.Objects.equals(opacityOpacity, themeConfig.opacityOpacity)
			&& java.util.Objects.equals(paddingPadding, themeConfig.paddingPadding)
			&& java.util.Objects.equals(panelBackground, themeConfig.panelBackground)
			&& java.util.Objects.equals(panelPadding, themeConfig.panelPadding)
			&& java.util.Objects.equals(progressTrackBackground, themeConfig.progressTrackBackground)
			&& java.util.Objects.equals(progressFillBackground, themeConfig.progressFillBackground)
			&& java.util.Objects.equals(progressTrackEdgeInsets, themeConfig.progressTrackEdgeInsets)
			&& java.util.Objects.equals(progressFillEdgeInsets, themeConfig.progressFillEdgeInsets)
			&& java.util.Objects.equals(progressFillMargin, themeConfig.progressFillMargin)
			&& java.util.Objects.equals(progressFillMode, themeConfig.progressFillMode)
			&& java.util.Objects.equals(progressMinValue, themeConfig.progressMinValue)
			&& java.util.Objects.equals(progressMaxValue, themeConfig.progressMaxValue)
			&& java.util.Objects.equals(progressValue, themeConfig.progressValue)
			&& java.util.Objects.equals(rowGapSize, themeConfig.rowGapSize)
			&& java.util.Objects.equals(rowMainAxisAlignment, themeConfig.rowMainAxisAlignment)
			&& java.util.Objects.equals(rowCrossAxisAlignment, themeConfig.rowCrossAxisAlignment)
			&& java.util.Objects.equals(scaledScale, themeConfig.scaledScale)
			&& java.util.Objects.equals(sizedUseIntrinsicWidth, themeConfig.sizedUseIntrinsicWidth)
			&& java.util.Objects.equals(sizedUseIntrinsicHeight, themeConfig.sizedUseIntrinsicHeight)
			&& java.util.Objects.equals(sizedFractionalWidth, themeConfig.sizedFractionalWidth)
			&& java.util.Objects.equals(sizedFractionalHeight, themeConfig.sizedFractionalHeight)
			&& java.util.Objects.equals(sizedFixedWidth, themeConfig.sizedFixedWidth)
			&& java.util.Objects.equals(sizedFixedHeight, themeConfig.sizedFixedHeight)
			&& java.util.Objects.equals(sliderThumbBackground, themeConfig.sliderThumbBackground)
			&& java.util.Objects.equals(sliderThumbEdgeInsets, themeConfig.sliderThumbEdgeInsets)
			&& java.util.Objects.equals(sliderThumbWidth, themeConfig.sliderThumbWidth)
			&& java.util.Objects.equals(sliderThumbHeight, themeConfig.sliderThumbHeight)
			&& java.util.Objects.equals(sliderTrackBackground, themeConfig.sliderTrackBackground)
			&& java.util.Objects.equals(sliderFillBackground, themeConfig.sliderFillBackground)
			&& java.util.Objects.equals(sliderTrackEdgeInsets, themeConfig.sliderTrackEdgeInsets)
			&& java.util.Objects.equals(sliderFillEdgeInsets, themeConfig.sliderFillEdgeInsets)
			&& java.util.Objects.equals(sliderFillMargin, themeConfig.sliderFillMargin)
			&& java.util.Objects.equals(sliderFillMode, themeConfig.sliderFillMode)
			&& java.util.Objects.equals(sliderMinValue, themeConfig.sliderMinValue)
			&& java.util.Objects.equals(sliderMaxValue, themeConfig.sliderMaxValue)
			&& java.util.Objects.equals(sliderValue, themeConfig.sliderValue)
			&& java.util.Objects.equals(textText, themeConfig.textText)
			&& java.util.Objects.equals(textFont, themeConfig.textFont)
			&& java.util.Objects.equals(textFontSize, themeConfig.textFontSize)
			&& java.util.Objects.equals(textFontHeightRatio, themeConfig.textFontHeightRatio)
			&& java.util.Objects.equals(textFontStyle, themeConfig.textFontStyle)
			&& java.util.Objects.equals(textColor, themeConfig.textColor)
			&& java.util.Objects.equals(textBackgroundColor, themeConfig.textBackgroundColor)
			&& java.util.Objects.equals(textAlignment, themeConfig.textAlignment)
			&& java.util.Objects.equals(textShadowEnabled, themeConfig.textShadowEnabled)
			&& java.util.Objects.equals(textShadowOffsetX, themeConfig.textShadowOffsetX)
			&& java.util.Objects.equals(textShadowOffsetY, themeConfig.textShadowOffsetY)
			&& java.util.Objects.equals(textShadowColor, themeConfig.textShadowColor);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Theme themeWidget = (dev.gamekit.ui.widgets.Theme) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		themeWidget.alignHorizontalAlignment = coalesce(alignHorizontalAlignment, nearestTheme.alignHorizontalAlignment);
		themeWidget.alignVerticalAlignment = coalesce(alignVerticalAlignment, nearestTheme.alignVerticalAlignment);
		themeWidget.buttonDefaultBackground = coalesce(buttonDefaultBackground, nearestTheme.buttonDefaultBackground);
		themeWidget.buttonHoverBackground = coalesce(buttonHoverBackground, nearestTheme.buttonHoverBackground);
		themeWidget.buttonPressedBackground = coalesce(buttonPressedBackground, nearestTheme.buttonPressedBackground);
		themeWidget.buttonPadding = coalesce(buttonPadding, nearestTheme.buttonPadding);
		themeWidget.checkboxDefaultIcon = coalesce(checkboxDefaultIcon, nearestTheme.checkboxDefaultIcon);
		themeWidget.checkboxToggledIcon = coalesce(checkboxToggledIcon, nearestTheme.checkboxToggledIcon);
		themeWidget.checkboxIconPadding = coalesce(checkboxIconPadding, nearestTheme.checkboxIconPadding);
		themeWidget.checkboxIconWidth = coalesce(checkboxIconWidth, nearestTheme.checkboxIconWidth);
		themeWidget.checkboxIconHeight = coalesce(checkboxIconHeight, nearestTheme.checkboxIconHeight);
		themeWidget.checkboxGapSize = coalesce(checkboxGapSize, nearestTheme.checkboxGapSize);
		themeWidget.checkboxToggled = coalesce(checkboxToggled, nearestTheme.checkboxToggled);
		themeWidget.coloredColor = coalesce(coloredColor, nearestTheme.coloredColor);
		themeWidget.coloredBorderRadius = coalesce(coloredBorderRadius, nearestTheme.coloredBorderRadius);
		themeWidget.columnGapSize = coalesce(columnGapSize, nearestTheme.columnGapSize);
		themeWidget.columnMainAxisAlignment = coalesce(columnMainAxisAlignment, nearestTheme.columnMainAxisAlignment);
		themeWidget.columnCrossAxisAlignment = coalesce(columnCrossAxisAlignment, nearestTheme.columnCrossAxisAlignment);
		themeWidget.fieldDefaultBackground = coalesce(fieldDefaultBackground, nearestTheme.fieldDefaultBackground);
		themeWidget.fieldFocusBackground = coalesce(fieldFocusBackground, nearestTheme.fieldFocusBackground);
		themeWidget.fieldEdgeInsets = coalesce(fieldEdgeInsets, nearestTheme.fieldEdgeInsets);
		themeWidget.fieldPadding = coalesce(fieldPadding, nearestTheme.fieldPadding);
		themeWidget.fieldText = coalesce(fieldText, nearestTheme.fieldText);
		themeWidget.fieldFont = coalesce(fieldFont, nearestTheme.fieldFont);
		themeWidget.fieldFontSize = coalesce(fieldFontSize, nearestTheme.fieldFontSize);
		themeWidget.fieldFontHeightRatio = coalesce(fieldFontHeightRatio, nearestTheme.fieldFontHeightRatio);
		themeWidget.fieldFontStyle = coalesce(fieldFontStyle, nearestTheme.fieldFontStyle);
		themeWidget.fieldColor = coalesce(fieldColor, nearestTheme.fieldColor);
		themeWidget.fieldBackgroundColor = coalesce(fieldBackgroundColor, nearestTheme.fieldBackgroundColor);
		themeWidget.fieldAlignment = coalesce(fieldAlignment, nearestTheme.fieldAlignment);
		themeWidget.fieldShadowEnabled = coalesce(fieldShadowEnabled, nearestTheme.fieldShadowEnabled);
		themeWidget.fieldShadowOffsetX = coalesce(fieldShadowOffsetX, nearestTheme.fieldShadowOffsetX);
		themeWidget.fieldShadowOffsetY = coalesce(fieldShadowOffsetY, nearestTheme.fieldShadowOffsetY);
		themeWidget.fieldShadowColor = coalesce(fieldShadowColor, nearestTheme.fieldShadowColor);
		themeWidget.flexGapSize = coalesce(flexGapSize, nearestTheme.flexGapSize);
		themeWidget.flexMainAxisAlignment = coalesce(flexMainAxisAlignment, nearestTheme.flexMainAxisAlignment);
		themeWidget.flexCrossAxisAlignment = coalesce(flexCrossAxisAlignment, nearestTheme.flexCrossAxisAlignment);
		themeWidget.gapWidth = coalesce(gapWidth, nearestTheme.gapWidth);
		themeWidget.gapHeight = coalesce(gapHeight, nearestTheme.gapHeight);
		themeWidget.imageFit = coalesce(imageFit, nearestTheme.imageFit);
		themeWidget.imageInterpolation = coalesce(imageInterpolation, nearestTheme.imageInterpolation);
		themeWidget.opacityOpacity = coalesce(opacityOpacity, nearestTheme.opacityOpacity);
		themeWidget.paddingPadding = coalesce(paddingPadding, nearestTheme.paddingPadding);
		themeWidget.panelBackground = coalesce(panelBackground, nearestTheme.panelBackground);
		themeWidget.panelPadding = coalesce(panelPadding, nearestTheme.panelPadding);
		themeWidget.progressTrackBackground = coalesce(progressTrackBackground, nearestTheme.progressTrackBackground);
		themeWidget.progressFillBackground = coalesce(progressFillBackground, nearestTheme.progressFillBackground);
		themeWidget.progressTrackEdgeInsets = coalesce(progressTrackEdgeInsets, nearestTheme.progressTrackEdgeInsets);
		themeWidget.progressFillEdgeInsets = coalesce(progressFillEdgeInsets, nearestTheme.progressFillEdgeInsets);
		themeWidget.progressFillMargin = coalesce(progressFillMargin, nearestTheme.progressFillMargin);
		themeWidget.progressFillMode = coalesce(progressFillMode, nearestTheme.progressFillMode);
		themeWidget.progressMinValue = coalesce(progressMinValue, nearestTheme.progressMinValue);
		themeWidget.progressMaxValue = coalesce(progressMaxValue, nearestTheme.progressMaxValue);
		themeWidget.progressValue = coalesce(progressValue, nearestTheme.progressValue);
		themeWidget.rowGapSize = coalesce(rowGapSize, nearestTheme.rowGapSize);
		themeWidget.rowMainAxisAlignment = coalesce(rowMainAxisAlignment, nearestTheme.rowMainAxisAlignment);
		themeWidget.rowCrossAxisAlignment = coalesce(rowCrossAxisAlignment, nearestTheme.rowCrossAxisAlignment);
		themeWidget.scaledScale = coalesce(scaledScale, nearestTheme.scaledScale);
		themeWidget.sizedUseIntrinsicWidth = coalesce(sizedUseIntrinsicWidth, nearestTheme.sizedUseIntrinsicWidth);
		themeWidget.sizedUseIntrinsicHeight = coalesce(sizedUseIntrinsicHeight, nearestTheme.sizedUseIntrinsicHeight);
		themeWidget.sizedFractionalWidth = coalesce(sizedFractionalWidth, nearestTheme.sizedFractionalWidth);
		themeWidget.sizedFractionalHeight = coalesce(sizedFractionalHeight, nearestTheme.sizedFractionalHeight);
		themeWidget.sizedFixedWidth = coalesce(sizedFixedWidth, nearestTheme.sizedFixedWidth);
		themeWidget.sizedFixedHeight = coalesce(sizedFixedHeight, nearestTheme.sizedFixedHeight);
		themeWidget.sliderThumbBackground = coalesce(sliderThumbBackground, nearestTheme.sliderThumbBackground);
		themeWidget.sliderThumbEdgeInsets = coalesce(sliderThumbEdgeInsets, nearestTheme.sliderThumbEdgeInsets);
		themeWidget.sliderThumbWidth = coalesce(sliderThumbWidth, nearestTheme.sliderThumbWidth);
		themeWidget.sliderThumbHeight = coalesce(sliderThumbHeight, nearestTheme.sliderThumbHeight);
		themeWidget.sliderTrackBackground = coalesce(sliderTrackBackground, nearestTheme.sliderTrackBackground);
		themeWidget.sliderFillBackground = coalesce(sliderFillBackground, nearestTheme.sliderFillBackground);
		themeWidget.sliderTrackEdgeInsets = coalesce(sliderTrackEdgeInsets, nearestTheme.sliderTrackEdgeInsets);
		themeWidget.sliderFillEdgeInsets = coalesce(sliderFillEdgeInsets, nearestTheme.sliderFillEdgeInsets);
		themeWidget.sliderFillMargin = coalesce(sliderFillMargin, nearestTheme.sliderFillMargin);
		themeWidget.sliderFillMode = coalesce(sliderFillMode, nearestTheme.sliderFillMode);
		themeWidget.sliderMinValue = coalesce(sliderMinValue, nearestTheme.sliderMinValue);
		themeWidget.sliderMaxValue = coalesce(sliderMaxValue, nearestTheme.sliderMaxValue);
		themeWidget.sliderValue = coalesce(sliderValue, nearestTheme.sliderValue);
		themeWidget.textText = coalesce(textText, nearestTheme.textText);
		themeWidget.textFont = coalesce(textFont, nearestTheme.textFont);
		themeWidget.textFontSize = coalesce(textFontSize, nearestTheme.textFontSize);
		themeWidget.textFontHeightRatio = coalesce(textFontHeightRatio, nearestTheme.textFontHeightRatio);
		themeWidget.textFontStyle = coalesce(textFontStyle, nearestTheme.textFontStyle);
		themeWidget.textColor = coalesce(textColor, nearestTheme.textColor);
		themeWidget.textBackgroundColor = coalesce(textBackgroundColor, nearestTheme.textBackgroundColor);
		themeWidget.textAlignment = coalesce(textAlignment, nearestTheme.textAlignment);
		themeWidget.textShadowEnabled = coalesce(textShadowEnabled, nearestTheme.textShadowEnabled);
		themeWidget.textShadowOffsetX = coalesce(textShadowOffsetX, nearestTheme.textShadowOffsetX);
		themeWidget.textShadowOffsetY = coalesce(textShadowOffsetY, nearestTheme.textShadowOffsetY);
		themeWidget.textShadowColor = coalesce(textShadowColor, nearestTheme.textShadowColor);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<ThemeConfig> { }
}