package dev.gamekit.ui.widgets;

import static dev.gamekit.utils.Misc.coalesce;

public class ColumnConfig extends dev.gamekit.ui.widgets.FlexConfig implements Widget.Config {
	public java.lang.Integer gapSize;
	public dev.gamekit.ui.enums.MainAxisAlignment mainAxisAlignment;
	public dev.gamekit.ui.enums.CrossAxisAlignment crossAxisAlignment;

	@Override
	public boolean equals(Object obj) {
		return obj instanceof ColumnConfig columnConfig
			&& java.util.Objects.equals(gapSize, columnConfig.gapSize)
			&& java.util.Objects.equals(mainAxisAlignment, columnConfig.mainAxisAlignment)
			&& java.util.Objects.equals(crossAxisAlignment, columnConfig.crossAxisAlignment);
	}

	@Override
	public void updateWidget(Widget widget) {
		dev.gamekit.ui.widgets.Column columnWidget = (dev.gamekit.ui.widgets.Column) widget;
		Theme nearestTheme = coalesce(widget.getAncestorOfType(Theme.class), Theme.DEFAULT);
		columnWidget.gapSize = coalesce(gapSize, nearestTheme.columnGapSize);
		columnWidget.mainAxisAlignment = coalesce(mainAxisAlignment, nearestTheme.columnMainAxisAlignment);
		columnWidget.crossAxisAlignment = coalesce(crossAxisAlignment, nearestTheme.columnCrossAxisAlignment);
	}

	@FunctionalInterface
	public interface Updater extends Widget.ConfigUpdater<ColumnConfig> { }
}